# greetings.py
# Name:
# Collaborators:
 
 
# Variables make saying hello and goodbye super easy!
 
saying_1 = 'Let Them Eat Cake'
saying_2 = 'The Rich get Richer'
greeting = 'Hello, world!'
name = 'Cynthia Skier'
space = ' '
star = '*'
 
# You may only use the variables defined above. 
# For example, if you wanted to print
# a "T" in stars, you would do:
 
# print(star * 3)
# print(space + star + space)
# print(space + star + space)
 
# The answer below would not be acceptable:
# print('***')
# print(' * ')
# print(' * ')

# Print "Eat The Rich" and "Hello, Cynthia" using only the above variables
