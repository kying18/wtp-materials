# desserts.py
# Name :
# Collaborators :

# This program prints out recipes for desserts.

print('Tiramisu (Wolfgang Puck)')
print('Ladyfingers: ')
print('* 6 eggs, separated')
print('* 1 cup cake flour, sifted')
print('* Melted butter, for brushing pan')
print()
print('Mascarpone Cream: ') 
print('* 6 egg yolks')
print('* 1 cup sugar') 
print('* 1/3 cup Marsala') 
print('* 1/4 cup brandy') 
print('* 2 pounds mascarpone cheese')
print()
print('Espresso Syrup: ') 
print('* 1 cup espresso, hot') 
print('* 3 tablespoons brown sugar')
print('* 1 tablespoon sugar') 
print('* 1 teaspoon lemon juice')
print('* 1 teaspoon vanilla extract') 
print('* 1/2 cup grated bittersweet chocolate')
