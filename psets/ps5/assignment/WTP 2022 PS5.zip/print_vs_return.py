# print_vs_return.py
# Name:
# Collaborators:
 

def f1(x):
    print(x + 1)

def f2(x):
    return x + 1