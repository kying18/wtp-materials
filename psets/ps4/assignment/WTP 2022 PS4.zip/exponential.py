# exponential.py
# Name:
# Collaborators:

# This program writes our own version of 
# exponential, **

base = input('Base: ')
exp = input('Exponent: ')

### YOUR CODE HERE
result = 0 



###

print(result)