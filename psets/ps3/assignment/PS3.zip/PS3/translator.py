# translator.py
# Name:
# Collaborators:

# Here are the spanish numbers, spelled out from 0 to 9:
# cero uno dos tres cuatro cinco seis siete ocho nueve

# STEP 1: Make a dictionary that maps english numbers to spanish numbers
# For example, looking up "one" in the dictionary should return "uno".

numbers_translation = {}  # TODO fill in this dictionary


# STEP 2: Now ask your user to input a number spelled out in English

number = None    # TODO replace None here with a prompt that gets input from user

# STEP 3: Print out the spanish translation of each English number (in order)

# TODO print out the spanish translation
