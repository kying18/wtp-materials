# blackjack.py
# Name:
# Collaborators:

# Here is a dictionary, the keys of the dictionary correspond to the rows in
# the table, where the three values in the tuple are (card1, card2, dealer_card)
# Determine the output of the cards and make you answer the *value* to this
# tuple in the dictionary

blackjack_solution = {
    (3, 8, 4):              None,  # TODO replace None with your answer (string)
    (9, 8, 10):             None,  # TODO replace None with your answer (string)
    (11, 10, 10):           None,  # TODO replace None with your answer (string)
    (3, 5, 4):              None,  # TODO replace None with your answer (string)
    (5, 8, 8):              None,  # TODO replace None with your answer (string)
}
