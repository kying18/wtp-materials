# blackjack.py
# Name:
# Collaborators: 

# Fill in the table below

# | card1 | card2 | dealer_card | output |
# | ----- | ----- | ----------- | ------ |
# | 3     | 8     | 4           |        |
# | 9     | 8     | 10          |        |
# | 11    | 10    | 10          |        |
# | 3     | 5     | 4           |        |
# | 5     | 8     | 8           |        |

