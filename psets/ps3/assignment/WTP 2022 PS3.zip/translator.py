# translator.py
# Name:
# Collaborators:

## Here are the spanish numbers, spelled out from 0 to 9:
## cero uno dos tres cuatro cinco seis siete ocho nueve

## Make a dictionary that maps english numbers to spanish numbers. For example,
## looking up "one" in the dictionary should return "uno".




## Now ask your user to input a number spelled out in English


## Print out the spanish translation of each English number (in order) 
